+++
categories = ['reference']
description = 'Configure all things sidebar'
title = 'Sidebar'
weight = 3

[params]
  alwaysopen = false
+++

{{% children type="list" description=true %}}
