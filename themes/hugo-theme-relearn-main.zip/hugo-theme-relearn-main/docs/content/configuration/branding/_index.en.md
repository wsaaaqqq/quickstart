+++
categories = ['reference']
description = 'Change colors and logos of your site'
title = 'Branding'
weight = 2

[params]
  alwaysopen = false
+++

{{% children type="list" description=true %}}
