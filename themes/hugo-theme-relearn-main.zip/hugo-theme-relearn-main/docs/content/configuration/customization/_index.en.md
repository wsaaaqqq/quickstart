+++
categories = ['reference']
description = 'Customize files for advanced usage'
title = 'Customization'
weight = 5

[params]
  alwaysopen = false
+++

{{% children type="list" description=true %}}
