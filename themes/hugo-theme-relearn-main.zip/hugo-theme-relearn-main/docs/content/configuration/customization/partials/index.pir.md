+++
categories = ['explanation']
description = 'Modifying partials to your needs'
title = 'Partials'
weight = 1
+++
{{< piratify >}}