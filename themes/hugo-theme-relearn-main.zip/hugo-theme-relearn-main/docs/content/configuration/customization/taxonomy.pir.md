+++
categories = ['explanation', 'howto', 'reference']
description = 'How to display custom taxonomies on your pages'
tags = ['taxonomy']
title = 'Taxonomies'
weight = 8
+++
{{< piratify >}}