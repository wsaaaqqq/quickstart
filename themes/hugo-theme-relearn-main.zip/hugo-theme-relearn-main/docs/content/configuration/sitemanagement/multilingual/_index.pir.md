+++
categories = ['howto']
description = 'How to set up a multilingual site'
options = ['disableLanguageSwitchingButton']
title = 'Multilingual'
weight = 2
+++
{{< piratify >}}