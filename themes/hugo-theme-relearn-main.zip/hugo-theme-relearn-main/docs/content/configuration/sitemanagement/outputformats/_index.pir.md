+++
categories = ['howto']
description = 'What formats can a page be displayed in'
outputs = ['html', 'rss', 'print', 'markdown', 'source']
title = 'Available Output Formats'
weight = 7
+++
{{< piratify >}}