+++
categories = ['howto']
description = 'Display page meta information with your content'
options = ['dateFormat', 'hideAuthorName', 'hideAuthorEmail', 'hideAuthorDate']
title = 'Page Meta Information'
weight = 3
+++
{{< piratify >}}