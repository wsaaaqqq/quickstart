+++
categories = ['reference']
title = 'Configuration'
type = 'chapter'
weight = 2

[params]
  menuPre = "<i class='fa-fw fas fa-gears'></i> "
+++

Find out how to configure and customize your site.

{{% children type="list" description=true %}}
