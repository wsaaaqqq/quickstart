+++
title = 'Version 2.6'
type = 'changelog'
weight = -6

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
