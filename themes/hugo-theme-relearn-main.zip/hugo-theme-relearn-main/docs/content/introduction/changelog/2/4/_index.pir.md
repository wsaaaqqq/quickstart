+++
title = 'Version 2.4'
type = 'changelog'
weight = -4

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
