+++
title = 'Version 3'
type = 'changelog'
weight = -3

[params]
  disableToc = false
+++

{{% pages showhidden="true" showdivider="true" %}}
