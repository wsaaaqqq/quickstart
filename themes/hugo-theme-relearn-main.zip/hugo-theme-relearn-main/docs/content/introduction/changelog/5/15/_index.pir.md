+++
title = 'Version 5.15'
type = 'changelog'
weight = -15

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
