+++
title = 'Version 5.13'
type = 'changelog'
weight = -13

[params]
  disableToc = false
  hidden = true
+++
{{< piratify >}}
