+++
title = 'Introduction'
type = 'chapter'
weight = 1

[params]
  menuPre = "<i class='fa-fw fas fa-star'></i> "
+++

Discover what this Hugo theme is all about.

{{% children type="list" description=true %}}
