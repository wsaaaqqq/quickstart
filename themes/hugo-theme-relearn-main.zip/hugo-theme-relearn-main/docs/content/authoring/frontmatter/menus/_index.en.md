+++
description = 'Setting the behavior of the menus'
title = 'Menus'
weight = 2

[params]
  menuPageRef = '/configuration/sidebar/menus#expand-state-of-submenus'
+++
