+++
categories = ['explanation']
description = 'How to apply effects to your images'
frontmatter = ['imageEffects']
title = 'Image Effects'
weight = 3
+++
{{< piratify >}}