+++
categories = ['explanation']
description = 'How to link to pages and resources'
title = 'Pages & Resources'
weight = 1
+++
{{< piratify >}}