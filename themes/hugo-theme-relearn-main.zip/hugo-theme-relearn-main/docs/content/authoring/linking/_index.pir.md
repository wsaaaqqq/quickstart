+++
categories = ['reference']
description = 'How to link your content'
title = 'Linking'
weight = 5

[params]
  alwaysopen = false
+++
{{< piratify >}}