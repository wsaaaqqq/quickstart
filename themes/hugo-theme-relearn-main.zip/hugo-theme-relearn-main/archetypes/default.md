+++
title = "{{ replace .Name "-" " " | title }}"
+++

This is a new page.